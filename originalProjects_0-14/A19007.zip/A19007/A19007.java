
import java.awt.* ;
import java.awt.event.*;
import javax.swing.* ;
import java.util.Scanner ;
import java.io.* ;

/**
@author Ramon Ortega (Email: <a href="ramon.justis.ortega@gmail.com"> ramon.justis.ortega@gmail.com</a>)
@version 1.00 10/13/2013
@assignment.number Creating a Form - A190-07
@prgm.usage Called from the operating system
@see "Gaddis, 2013, Starting out with Java, From Control Structures, 5th ed."
@see "<a href='http://java.sun.com/javase/6/docs/technotes/guides/javadoc/index.html'>JavaDoc Documentation</a>"
*/
public class A19007 extends JFrame
{
   //Section 710, declare variables
   private static int q = 0;        //a static variable for making sure we populate text fields only when both
                                    //an airport AND and altitude are selected
   private AirportDB db ;           //an AirportDB object to store airport weather into arrays
   private NWSFB fb ;               //an NWSFB object to get station weather data from a long string
   private Scanner inFile ;         //a Scanner object to hand the constructor
   private int intAirport ;         //an integer representing the index of an airport in an array
   private int StartIndex ;         //an integer used for storing the beginning index of the SAN airport in an ArrayList
   private String strAirport ;      //a string used for storing an aiport ID
   private String altitudeWeather;  //a string used for storing weather numbers at a certain altitude
   private String strAltitude ;     //a string used for storing the altitude
   private String windDirection;    //a string used for storing the wind direction
   private String windSpeed;        //a string used for storing the wind speed
   private String windTemp;         //a string used for storing the wind temperatur
   private JFrame frame ;           //a JFrame object used for creating a window
   private JPanel panel;            //a JPanel object used for sending information to the window
   private JLabel lblTitle;         //a JLabel object used to display the large title on the window
   private JComboBox cboApt ;       //a JComboBox object used to hold the 3 letter station ID's of airports
   private JComboBox cboAlt ;       //a JComboBox object used to hold the altitudes of certain airport weather strings
   private String[] wea;            //an array of strings used to hold weather for every aiport
   private String altArray[] =      {"03", "06", "09",   //an array of strings representing the 9 altitudes
                                    "12", "18", "24", 
                                    "30", "34", "39"} ;
                               
  	/**
	This is the constructor for the 19007 class. It reads an input file
	from the main method, formates and stores the data in ArrayList databases
   using the AirportDB class, and then initializes class level variables based
   on the data in the databases
	  
   @param inputFile a scanner object containing national weather report
   */                                                               
   public A19007(Scanner inputFile) //the constructor assignes values from the FBIN.txt file to class variables
   {
      //Section 721 initialize an array containing weather data
      wea = new String[21];
      db = new AirportDB(inputFile);                     //hand the input file to be stored in a database
      StartIndex = db.getStationIndex("SAN") ;           //get the index number of the San Diego Airport
      for (int i = 0 ; i<21 ; i++ )                      //populate 21 airports starting with San Diego in an array
      {
         String strKey = db.getStationID(i+StartIndex) ;
         wea[i] = db.getStationWeather(strKey);
      }
      
      //Section 722 build the frame and panal
      final int WINDOW_WIDTH = 500 ;                     //size the  window
      final int WINDOW_HEIGHT = 400 ;
      frame = new JFrame() ;                             //make the window
      frame.setTitle("Demo Form 07") ;                   //title the top
      frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT) ;
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;   //let the window have an exit
      frame.setVisible(false) ;                          //first set the frame visibility to false, until later when
                                                         //we have populated the panel more
      panel = new JPanel(null) ;                         //initialize the panenl to null so we can use x y coordinate positions
      panel.setPreferredSize(new Dimension(350,250)) ;   //size the panel
      panel.setBackground(Color.lightGray) ;             //color the panel
      
      //Section 723
      //Instantiate a labels, combo boxes, and text fields
      //The large label title is special and needs its own formating
      lblTitle = new JLabel("Black Mountain Aviation Center");
      //Set the font to 24 points (24 points = 1 inch)
      lblTitle.setFont(new Font("Helvetica", Font.BOLD, 24)) ;
      //Set the label box to 410 pixels wide and 20 pixels high)
      lblTitle.setSize(410,25) ;
      //Set the label position to 15 pixels from the LEFT and 25 from the TOP     
      lblTitle.setLocation(45,25) ;
      //Set the label color to blue
      lblTitle.setForeground(Color.blue) ;
      //Add the label to the panel
      panel.add(lblTitle) ;

      //Create labels
      setLabel(50,100, "Select Airport") ;   //use a function to set airport label
      setLabel(50,175, "Select Altitude") ;  //use a function to set altitude label
      //Create labels for the wind direction, speed, and temperature text fields
      setLabel(250,100, "Wind Dir") ;
      setLabel(250,150, "Wind Speed") ;
      setLabel(250, 200, "Wind Temp") ;
      //Create labels for the author
      setLabel(50, 250, "Programmed by") ;
      setLabel(200, 250, "Ramon Ortega") ;
      //Create Comboboxes for the airport ID and the altitude using a function
      cboApt = setComboBox( 50, 125, wea ) ;                      //name the combobox
      cboApt.addActionListener(new MyComboBoxListenerClass());    //link the combobox to an actionlistenter
      cboAlt = setComboBox(50, 200, altArray );                   //name the combobox
      cboAlt.addActionListener(new MyComboBoxListenerClass()) ;   //link the combobox to an actionlistenter
      //Create the initial text field boxes for wind direction, speed, and temperature
      setTextField(325, 100, windDirection);
      setTextField(325, 150, windSpeed) ;
      setTextField(325, 200, windTemp) ;
      //Section 750, finish up the form
      frame.add(panel) ; 
   }     
   
   //Section 760, display the form
   
   /**
	This function is used by the main method to call the frame into visibility
   once all the panel components have been set up and linked to the frame
	  
   @param none
   */   
   public void display()
   {
      frame.setVisible(true);
   }
   //Section 770, display the text Boxes and their data
   
   /**
	This function is called whenever an a combobox item is selected. It makes
   sure that two combobox items, airport ID and altitude, must be selected in
   order for the wind direction, speed, and temperature text fields to update with
   correct weather information
	  
   @param strIndex an integer representing the index of the ariport in the airport
                     ComboBox.
   @param strAlt a 2 character string representing the weather altitude in thousands of
                  feet.
   */ 
    public void updateTextBoxes(int strIndex, String strAlt)
   {  
      q++;        //this static variable is incremented everytime this function is called
      if (q == 2) //only if an airport and an altitude is selected will text fields be populated
      {           //use the database to get the index of the airports in the comboboxes
      String strKey = db.getStationID(strIndex+db.getStationIndex("SAN"));
      String strStationWeather = db.getStationWeather(strKey)+" " ;
      fb = new NWSFB(strStationWeather);  //use this object to get information for alt and ID combinations
      altitudeWeather = fb.getAltitudeWeather(strAlt.substring(0,2)) ;
		windDirection = fb.getWindDirection(strAlt.substring(0,2));
		windSpeed = fb.getWindSpeed(strAlt.substring(0,2)) ;
		windTemp = fb.getWindTemp(strAlt.substring(0,2)) ;
      setTextField(325, 100, windDirection);
      setTextField(325, 150, windSpeed) ;
      setTextField(325, 200, windTemp) ;
      q = 0;      //when an airport and an altitude is
      }
      else        //when only one combobox is selected, don't display
      {           //stuff in the text fields
         windDirection = " " ;
         windSpeed = " ";
         windTemp = " " ;
         setTextField(325, 100, windDirection);
         setTextField(325, 150, windSpeed) ;
         setTextField(325, 200, windTemp) ;
      }
   }    
 
  /**
	This function is used by the constructor to create and position the airport and altitude 
   ComboBoxes on the frame
	  
   @param fmLeft an integer representing the number of pixels from the left of the frame
   @param fmTop an integer representing the number of pixels from the top of the frame
   @param strArray an array of strings representing the contents of the ComboBox list
   @return cbo a JComboBox object that is positioned on the panel
   */   
   public JComboBox setComboBox(int fmLeft, int fmTop, String[] strArray)
   {
      JComboBox cbo = new JComboBox() ;               //create a combobox
      cbo.setSize(100, 30) ;                          //width, height
      cbo.setLocation(fmLeft, fmTop);                 //from left, from top
      cbo.setForeground(Color.blue) ;                 //set the font color
      //populate the combobox with every index value in the strArray parameter
      for (int i = 0; i < strArray.length ; i++)     
      {
         if (strArray.length > 9)                     //if the array contains airports
         {
            cbo.addItem(strArray[i].substring(0,3)) ; //add the aiports to the combobox
         }
         else                                         //if the array contains altitudes
         {
            cbo.addItem(strArray[i] + "000" ) ;       //add the altitudes to the combobox
         }
      }
      panel.add(cbo) ;                                //add the combobox to the panel
      return cbo ;                                    //also return the combobox
   }
   /**
	This function is used by the constructor to create and position the wind direction,
   speed, and temperature text fields on the frame
	  
   @param fmLeft an integer representing the number of pixels from the left of the frame
   @param fmTop an integer representing the number of pixels from the top of the frame
   @param strVar a string object representing the contents that will be placed in the text field
   @return TextField a JTextField object that will contain weather information
   */ 
   public JTextField setTextField(int fmLeft, int fmTop, String strVar)
   {
      JTextField TextField = new JTextField(strVar) ; //create the text Field
      TextField.setFont(new Font("Helvetica", Font.BOLD,12)) ; //set font
      TextField.setEditable(false) ;                  //not editable
      TextField.setText(strVar) ;                     //place text in the field
      TextField.setSize(150,30);                      // Length, Height
      TextField.setLocation(fmLeft,fmTop) ;           //from left, from top
      TextField.setForeground(Color.blue) ;           //Colors pg 77
      TextField.setBorder(BorderFactory.createLineBorder(Color.black,1)) ; //add border
      panel.add(TextField) ;                          //add the TextField to the panel      
      return TextField ;                              //also return a Text Field object
   }
   /**
	This function is used by the constructor to create and position all the various small
   labels on the frame
	  
   @param fmLeft an integer representing the number of pixels from the left of the frame
   @param fmTop an integer representing the number of pixels from the top of the frame
   @param strVar a string object representing the contents that will be placed in the label
   @return label a JLabel object to label the components of the frame
   */ 
   public JLabel setLabel(int fmLeft, int fmTop, String strVar)
   {  
      JLabel label = new JLabel(strVar) ;                   //create the label
      label.setFont(new Font("Helvetica", Font.BOLD,12)) ;  //set the font
      label.setSize(100,20);                                // Length, Height
      label.setLocation(fmLeft,fmTop) ;                     //from left, from top
      label.setForeground(Color.blue) ;                     //Colors pg 778
      if(strVar.length() < 1 )
      {
         //BorderFactory pg 817
      	label.setBorder(BorderFactory.createLineBorder(Color.black,1)) ;
      }
      panel.add(label) ;                                    //add the label to the panel
      return label ;                                        //also return a JLabel object
   }
   //Section 783 , Combo boxes and actoin listeners 
   
   /**
   @author Ramon Ortega (Email: <a href="ramon.justis.ortega@gmail.com"> ramon.justis.ortega@gmail.com</a>)
   @version 1.00 10/13/2013
   @assignment.number Creating a Form - A190-07
   @prgm.usage Called from the operating system
   @see "Gaddis, 2013, Starting out with Java, From Control Structures, 5th ed."
   @see "<a href='http://java.sun.com/javase/6/docs/technotes/guides/javadoc/index.html'>JavaDoc Documentation</a>"
   */ 
   private class MyComboBoxListenerClass implements ActionListener
   {
      /**
	   This function is the required function for an action listener. It is used
      to call the updateTextBoxes function whenever a ComboBox Item is selected on 
      the frame by the user
	  
      @param event an ActionPerformed type that happenes everytime the actionlistener is notified
      */ 
      public void actionPerformed(ActionEvent event)
      {  
         
         intAirport = cboApt.getSelectedIndex();            //Gaddis,777
         
         strAltitude = (String)cboAlt.getSelectedItem() ;   //set the strAltitude variable to whatever
                                                            //is clicked in the altitude ComboBox
         
         updateTextBoxes(intAirport, strAltitude);          //call the updatTextBoxes function to deal
                                                            //with the events
      }
   }  
   
   
   /**
	This function is an embedded main function that first opens the input file
   and checks if it exists. It then implements the A19007 class by creating an 
   instance as an object. Finally, this function calls A19007's display method
   to display the window containing the components of the window
	  
   @param args an array of strings representing the arguments from the command line
   */ 
   public static void main(String[] args) throws IOException
   {
      File myFile = new File("FBIN.txt") ; //pg 246
		Scanner inputFile = new Scanner(myFile);
		
		//make sure the file exists
		if( !myFile.exists())
		{
			System.out.println("The file FBIN.txt cannot be found" ) ;
			System.exit(0) ;
		}
      //create an instance of A19007 and hand it's constructor the national weather file
      A19007 em = new A19007(inputFile) ;
      //Show the contents of the window to the user
      em.display() ;
   }
}  